﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
        }

        private void Рисовать_Click(object sender, EventArgs e)
        {

            Graphics gr = this.Картина.CreateGraphics();
                Pen myPen = new Pen(Color.Red, 2);
                gr.DrawRectangle(myPen, 50, 50, 80, 80);

                float radius = 40.0f;
                float diametr = radius * 2.0f;
                Graphics gr1 = this.Картина.CreateGraphics();
                Pen myPen1 = new Pen(Color.Red, 2);
                gr1.DrawEllipse(myPen1, 250, 50, diametr, diametr);

            float radius1 = 40.0f;
            float diametr1 = radius1 * 2.0f;
            Graphics gr10 = this.Картина.CreateGraphics();
            Pen myPen10 = new Pen(Color.Red, 2);
            gr10.DrawEllipse(myPen10, 50, 250, diametr1, diametr1);

            float radius10 = 40.0f;
            float diametr10 = radius10 * 2.0f;
            Graphics gr100 = this.Картина.CreateGraphics();
            Pen myPen100 = new Pen(Color.Red, 2);
            gr100.DrawEllipse(myPen100, 250, 250, diametr10, diametr10);
        }

        private void Картина_Paint(object sender, PaintEventArgs e)
        {
            SolidBrush LightPurpleBrush = new SolidBrush(Color.Purple);
            e.Graphics.FillRectangle(LightPurpleBrush, 30, 30, 120, 120);

            SolidBrush LightBlueBrush = new SolidBrush(Color.LightSkyBlue);
            e.Graphics.FillEllipse(LightBlueBrush, 230, 30, 120, 120);

            SolidBrush LightYellowBrush = new SolidBrush(Color.LightYellow);
            e.Graphics.FillEllipse(LightYellowBrush, 30, 230, 120, 120);

            SolidBrush LightORBrush = new SolidBrush(Color.OrangeRed);
            e.Graphics.FillEllipse(LightORBrush, 230, 230, 120, 120);

            Graphics gr = this.Картина.CreateGraphics();
            Pen myPen = new Pen(Color.Black, 2);
            gr.DrawRectangle(myPen, 50, 50, 80, 80);

            float radius = 40.0f;
            float diametr = radius * 2.0f;
            Pen myPen1 = new Pen(Color.Black, 2);
            e.Graphics.DrawEllipse(myPen1, 250, 50, diametr, diametr);

            float radius1 = 40.0f;
            float diametr1 = radius1 * 2.0f;
            Pen myPen10 = new Pen(Color.Black, 2);
            e.Graphics.DrawEllipse(myPen10, 50, 250, diametr1, diametr1);

            float radius10 = 40.0f;
            float diametr10 = radius10 * 2.0f;
            Pen myPen100 = new Pen(Color.Black, 2);
            e.Graphics.DrawEllipse(myPen100, 250, 250, diametr10, diametr10);

            Pen myPen8 = new Pen(Color.Red, 2);
            e.Graphics.DrawRectangle(myPen8, 50, 50, 80, 80);
        }
    }
}